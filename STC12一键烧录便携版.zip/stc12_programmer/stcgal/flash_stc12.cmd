@echo off
"%~dp0python\python.exe" -X utf8 "%~dp0flash_stc12.py" %*
exit /b %errorlevel%
