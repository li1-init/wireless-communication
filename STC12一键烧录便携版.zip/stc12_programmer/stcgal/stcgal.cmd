@echo off
"%~dp0python\python.exe" -X utf8 -c "import sys; from stcgal.frontend import cli; sys.exit(cli())" %*
exit /b %errorlevel%
